import pandas as pd
from .repo import list_transactions

def month_dataframe(month_prefix=None):
    rows = list_transactions(month_prefix)
    df = pd.DataFrame(rows, columns=['id','date','amount','description','payment','category'])
    return df

def category_summary(df: pd.DataFrame):
    if df.empty:
        return pd.DataFrame(columns=['category','total','share'])
    g = df.groupby('category', dropna=False)['amount'].sum().reset_index(name='total')
    g['share'] = (g['total'] / g['total'].sum() * 100).round(1)
    return g.sort_values('total', ascending=False)