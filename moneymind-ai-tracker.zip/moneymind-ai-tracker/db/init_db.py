import sqlite3, os
os.makedirs('db', exist_ok=True)
con = sqlite3.connect('db/finance.db')
cur = con.cursor()
cur.executescript('''
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL
);
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  t_date TEXT NOT NULL,
  amount REAL NOT NULL,
  description TEXT NOT NULL,
  payment_mode TEXT,
  category_id INTEGER,
  source TEXT DEFAULT 'manual',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id)
);
CREATE TABLE IF NOT EXISTS budgets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  month TEXT NOT NULL,
  category_id INTEGER NOT NULL,
  amount REAL NOT NULL,
  UNIQUE (month, category_id),
  FOREIGN KEY (category_id) REFERENCES categories(id)
);
''')
cats = ['Food','Travel','Shopping','Bills','Recharge','Health','Entertainment','Fees','Other']
for c in cats:
    cur.execute('INSERT OR IGNORE INTO categories(name) VALUES(?)', (c,))
con.commit(); con.close()
print('Initialized db/finance.db and seeded categories.')