import math

def tips_from_summary(total_spend, cat_summary_df, targets=None):
    tips = []
    if total_spend <= 0 or cat_summary_df.empty:
        return ['Add transactions to see insights.']
    for _, row in cat_summary_df.iterrows():
        cat = row['category'] or 'Uncategorized'
        total = float(row['total'])
        share = float(row['share'])
        target = (targets or {}).get(cat, 30.0)  # default 30%
        if share > target + 5:
            cut = min(10, math.ceil(share - target))
            save = round(total * cut / share)
            tips.append(f"{cat}: {share}% of spend. Trim ~{cut}% (~₹{save}) next month.")
    if not tips:
        tips.append('Good balance. Maintain categories under targets.')
    return tips