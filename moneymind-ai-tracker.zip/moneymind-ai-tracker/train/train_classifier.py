import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
import joblib

os.makedirs('models', exist_ok=True)

df = pd.read_csv('data/labeled_samples.csv')
X = df['description'].astype(str)
y = df['category'].astype(str)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

vec = TfidfVectorizer(ngram_range=(1,2), min_df=1)
Xtr = vec.fit_transform(X_train)
Xte = vec.transform(X_test)

clf = LogisticRegression(max_iter=300)
clf.fit(Xtr, y_train)

y_pred = clf.predict(Xte)
print('Accuracy:', accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))

joblib.dump(vec, 'models/vectorizer.pkl')
joblib.dump(clf, 'models/expense_clf.pkl')
print('Saved models/vectorizer.pkl and models/expense_clf.pkl')