# MoneyMind — AI-Powered Personal Finance Tracker (Beginner-Friendly)

A simple, college-ready finance tracker with a clean **Streamlit UI** and an **AI expense auto-categorizer** (TF‑IDF + Logistic Regression). 
Built to be **easy to understand, demo, and explain**.

## Features
- Add expenses via UI
- Auto-categorize by AI (Food, Travel, Shopping, Bills, Recharge, Health, Entertainment, Fees, Other)
- Dashboard with charts (category totals, shares, total spend)
- CSV import & export
- Rule-based monthly tips

## Tech
- Python, Streamlit UI
- SQLite (local file) for storage
- scikit-learn for ML

## Quickstart
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt

python db/init_db.py
python train/train_classifier.py
streamlit run app.py
```

## Project Structure
```
moneymind-ai-tracker/
├─ app.py
├─ requirements.txt
├─ db/
│   └─ init_db.py
├─ data/
│   └─ labeled_samples.csv
├─ models/
│   ├─ vectorizer.pkl
│   └─ expense_clf.pkl
├─ src/
│   ├─ __init__.py
│   ├─ repo.py
│   ├─ analytics.py
│   ├─ tips.py
│   └─ categorize.py
└─ train/
    └─ train_classifier.py
```

## Notes
- Model files are created after you run the training script.
- You can expand the labeled dataset in `data/labeled_samples.csv` to improve accuracy.