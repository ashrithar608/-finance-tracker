import sqlite3
from contextlib import closing

DB_PATH = 'db/finance.db'

def connect():
    return sqlite3.connect(DB_PATH)

def get_category_id(name):
    with closing(connect()) as con:
        row = con.execute('SELECT id FROM categories WHERE name=?', (name,)).fetchone()
        return row[0] if row else None

def add_transaction(t_date, amount, description, payment_mode, category_id=None, source='manual'):
    with closing(connect()) as con:
        cur = con.cursor()
        cur.execute('''INSERT INTO transactions(t_date,amount,description,payment_mode,category_id,source)
                       VALUES(?,?,?,?,?,?)''',
                    (t_date, amount, description, payment_mode, category_id, source))
        con.commit()

def list_transactions(month_prefix=None):
    q = '''SELECT t.id, t.t_date, t.amount, t.description, t.payment_mode, c.name as category
           FROM transactions t LEFT JOIN categories c ON t.category_id=c.id'''
    params = []
    if month_prefix:
        q += ' WHERE substr(t.t_date,1,7)=?'
        params.append(month_prefix)
    q += ' ORDER BY t.t_date DESC, t.id DESC'
    with closing(connect()) as con:
        return con.execute(q, params).fetchall()