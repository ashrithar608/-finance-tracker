import streamlit as st
import pandas as pd
from datetime import date
from src import repo, analytics, tips
from src.categorize import predict_category

st.set_page_config(page_title='MoneyMind — AI Finance Tracker', layout='wide')
st.title('💸 MoneyMind — AI-Powered Personal Finance Tracker')

st.sidebar.header('Filters')
month = st.sidebar.text_input('Month (YYYY-MM)', value=pd.Timestamp.today().strftime('%Y-%m'))

st.sidebar.markdown('---')
st.sidebar.write('Quick actions')
if st.sidebar.button('Seed demo transactions'):
    # Seed a few transactions for the current month for demo
    today = pd.Timestamp.today()
    demo = [
        (today.strftime("%Y-%m-%d"), 220, "Swiggy biryani", "upi"),
        (today.strftime("%Y-%m-%d"), 45, "Tea canteen", "cash"),
        (today.strftime("%Y-%m-%d"), 120, "BMTC bus ticket", "upi"),
        (today.strftime("%Y-%m-%d"), 499, "Airtel prepaid recharge", "upi"),
        (today.strftime("%Y-%m-%d"), 899, "Flipkart shoes", "card"),
    ]
    for d in demo:
        cat, conf, mode = predict_category(d[2])
        cat_id = repo.get_category_id(cat)
        repo.add_transaction(d[0], d[1], d[2], d[3], cat_id, source='seed')
    st.sidebar.success('Seeded demo transactions.')

st.subheader('Add Transaction')
with st.form('add_txn', clear_on_submit=True):
    c1, c2, c3 = st.columns([1,1,2])
    t_date = c1.date_input('Date', value=date.today())
    amount = c2.number_input('Amount (₹)', min_value=0.0, step=10.0, help="Enter positive amount")
    desc = c3.text_input('Description (merchant, item)', help="e.g., Swiggy biryani, Metro top-up, Airtel recharge")
    pay = st.selectbox('Payment Mode', ['cash','upi','card'])
    auto = st.checkbox('Auto-categorize with AI', value=True)
    submitted = st.form_submit_button('Add Transaction')
    if submitted:
        cat_id = None
        if auto and desc.strip():
            cat, conf, mode = predict_category(desc)
            st.info(f'Predicted category: **{cat}** (via {mode}, conf≈{conf:.2f})')
            cat_id = repo.get_category_id(cat)
        repo.add_transaction(str(t_date), float(amount), desc.strip(), pay, cat_id)
        st.success('Saved.')

st.subheader('Import CSV')
csv = st.file_uploader('Upload CSV with columns: t_date,amount,description,payment_mode', type=['csv'])
if csv:
    df_imp = pd.read_csv(csv)
    st.dataframe(df_imp.head())
    if st.button('Auto-categorize & Save imported rows'):
        for _, row in df_imp.iterrows():
            cat, conf, mode = predict_category(str(row['description']))
            cat_id = repo.get_category_id(cat)
            repo.add_transaction(str(row['t_date']), float(row['amount']), str(row['description']), str(row.get('payment_mode','upi')), cat_id, source='import')
        st.success('Imported and categorized.')

st.header('📊 Dashboard')
df = analytics.month_dataframe(month)
st.dataframe(df)

cat_sum = analytics.category_summary(df)
if not cat_sum.empty:
    st.bar_chart(cat_sum.set_index('category')['total'])
    st.write(cat_sum)
    total_spend = float(cat_sum['total'].sum())
else:
    st.write("No data for this month yet.")
    total_spend = 0.0

st.metric('Total Spend (₹)', f"{total_spend:,.0f}")

st.subheader('💡 Tips')
for t in tips.tips_from_summary(total_spend, cat_sum):
    st.write('• ' + t)

# Export current month CSV
if not df.empty:
    st.download_button(
        'Export current month CSV',
        data=df.to_csv(index=False).encode('utf-8'),
        file_name=f'transactions_{month}.csv',
        mime='text/csv'
    )

st.caption('If predictions show "untrained", run: `python train/train_classifier.py` to generate the model.')