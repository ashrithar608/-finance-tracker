import joblib
from pathlib import Path

VEC_PATH = Path('models/vectorizer.pkl')
CLF_PATH = Path('models/expense_clf.pkl')

# Lazy load to allow app to run before training (handled with a friendly message)
_vec = None
_clf = None

KEYWORD_RULES = {
    'Food': ['swiggy','zomato','biryani','pizza','hotel','canteen','restaurant','tea','coffee','dosa','cafe','café'],
    'Travel': ['ola','uber','auto','bus','metro','bmtc','train','ticket','fuel','petrol','cab'],
    'Recharge': ['recharge','airtel','jio','vi','dth','data'],
    'Bills': ['electricity','bescom','water','gas','rent','bill'],
    'Shopping': ['amazon','myntra','flipkart','stationery','kurti','dress','shoes'],
    'Health': ['pharmacy','apollo','tablet','medicine','doctor','clinic'],
    'Entertainment': ['movie','pvr','netflix','spotify','prime'],
    'Fees': ['tuition','college','exam','fees']
}

def _ensure_loaded():
    global _vec, _clf
    if _vec is None and VEC_PATH.exists():
        _vec = joblib.load(VEC_PATH)
    if _clf is None and CLF_PATH.exists():
        _clf = joblib.load(CLF_PATH)

def rule_guess(desc: str):
    d = desc.lower()
    for cat, words in KEYWORD_RULES.items():
        if any(w in d for w in words):
            return cat
    return None

def predict_category(description: str):
    desc = (description or '').strip()
    if not desc:
        return 'Other', 0.0, 'empty'
    # Rule first (fast and robust for small datasets)
    r = rule_guess(desc)
    if r:
        return r, 0.55, 'rule'
    # ML if available
    _ensure_loaded()
    if _vec is None or _clf is None:
        return 'Other', 0.0, 'untrained'
    X = _vec.transform([desc])
    proba = None
    if hasattr(_clf, 'predict_proba'):
        proba = float(_clf.predict_proba(X).max())
    y = _clf.predict(X)[0]
    return y, (proba if proba is not None else 0.0), 'ml'